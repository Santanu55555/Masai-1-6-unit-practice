import './App.css';
import Github from './components/GithubRepos';
import Stopwatch from './components/Stopwatch';


import TimerStopwatch from './components/TimerStopwatch';

function App() {
  return (
    <div className="App">
   
      {/* <Github/> */}
   
        <TimerStopwatch />
    </div>
  );
}

export default App;
