import logo from './logo.svg';
import './App.css';
import Rest from'./Q1/Rest'
import Timer from './Q2/Timer';

function App() {
  return (
    <div className="App">
      <Rest/>
      {/* <Timer/> */}
    </div>
  );
}

export default App;
